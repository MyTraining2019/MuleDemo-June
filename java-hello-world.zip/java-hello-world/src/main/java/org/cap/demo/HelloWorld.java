package org.cap.demo;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class HelloWorld extends AbstractTransformer {

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		System.out.println("My Object:" + src.toString());
		System.out.println("String Name:" + enc);
		return "Hello World";
	}

}
